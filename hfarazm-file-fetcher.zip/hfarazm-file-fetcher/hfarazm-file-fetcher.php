<?php
/*
Plugin Name:       Hfarazm File Fetcher
Plugin URI:        https://hfarazm.com/plugins/hfarazm-file-fetcher
Description:       Fetch any remote file with ultra fast speed into your WordPress directory.
Version:           2.6
Author:            Hfarazm Software LLC
Author URI:        https://hfarazm.com/plugins
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:       hfarazm-file-fetcher
Domain Path:       /languages
Requires at least: 5.0
Requires PHP:      7.2
Tested up to:      6.9
*/

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Admin menu ───────────────────────────────────────────────────────────────
add_action('admin_menu', function() {
    add_menu_page(
        __( 'Hfarazm File Fetcher', 'hfarazm-file-fetcher' ),
        __( 'File Fetcher', 'hfarazm-file-fetcher' ),
        'manage_options',
        'remote-file-fetcher',
        'srf_fetcher_page',
        'dashicons-download',
        11
    );
});

// ── Helper: find next available filename (file_1.zip, file_2.zip …) ─────────
function srf_available_filename( $filename ) {
    $info    = pathinfo($filename);
    $base    = $info['filename'];
    $ext     = isset($info['extension']) ? '.' . $info['extension'] : '';
    $counter = 1;
    do {
        $candidate = $base . '_' . $counter . $ext;
        $counter++;
    } while ( file_exists( ABSPATH . $candidate ) );
    return $candidate;
}

// ── AJAX: start download ─────────────────────────────────────────────────────
add_action('wp_ajax_srf_start_download', function() {
    check_ajax_referer('srf_ajax_nonce', 'nonce');
    if ( ! current_user_can('manage_options') ) wp_die('Forbidden', 403);

    $url             = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );
    $conflict_action = sanitize_text_field( wp_unslash( $_POST['conflict_action'] ?? 'none' ) );
    $token           = sanitize_key( wp_unslash( $_POST['token'] ?? '' ) );

    // Allowlist conflict_action to prevent unexpected values
    if ( ! in_array( $conflict_action, [ 'none', 'overwrite', 'rename' ], true ) ) {
        $conflict_action = 'none';
    }

    if ( empty($url) || empty($token) ) {
        wp_send_json(['status' => 'error', 'message' => __( 'Invalid request.', 'hfarazm-file-fetcher' )]);
    }

    $parsed   = wp_parse_url($url);
    $filename = isset($parsed['path']) ? basename($parsed['path']) : '';

    if ( empty($filename) ) {
        wp_send_json(['status' => 'error', 'message' => __( 'Could not determine filename from URL.', 'hfarazm-file-fetcher' )]);
    }

    // Conflict check
    if ( file_exists( ABSPATH . $filename ) && $conflict_action === 'none' ) {
        wp_send_json([
            'status'   => 'conflict',
            'filename' => $filename,
            'renamed'  => srf_available_filename($filename),
        ]);
    }

    if ( $conflict_action === 'rename' ) {
        $filename = srf_available_filename($filename);
    } elseif ( $conflict_action === 'overwrite' && file_exists( ABSPATH . $filename ) ) {
        wp_delete_file( ABSPATH . $filename );
    }

    $full_path     = ABSPATH . $filename;
    $progress_file = sys_get_temp_dir() . '/srf_progress_' . $token . '.json';

    // HEAD request to get file size for progress display
    $head  = wp_remote_head( $url, [ 'timeout' => 15, 'redirection' => 5 ] );
    $total = 0;
    if ( ! is_wp_error($head) ) {
        $content_length = wp_remote_retrieve_header( $head, 'content-length' );
        $total          = $content_length ? absint($content_length) : 0;
    }

    // Write initial progress — store destination path so poller can read filesize()
    file_put_contents($progress_file, json_encode([
        'downloaded' => 0,
        'total'      => $total,
        'path'       => $full_path,
        'done'       => false,
    ]), LOCK_EX);

    // ── Download using WP HTTP API with streaming ─────────────────────────────
    $response = wp_remote_get( $url, [
        'timeout'  => 300,
        'stream'   => true,
        'filename' => $full_path,
    ]);

    if ( is_wp_error($response) ) {
        wp_delete_file( $full_path );
        file_put_contents($progress_file, json_encode(['done' => true, 'error' => true]), LOCK_EX);
        wp_send_json(['status' => 'error', 'message' => $response->get_error_message()]);
    }

    $http = wp_remote_retrieve_response_code($response);
    if ( $http >= 400 ) {
        wp_delete_file( $full_path );
        file_put_contents($progress_file, json_encode(['done' => true, 'error' => true]), LOCK_EX);
        /* translators: %s: HTTP status code */
        wp_send_json(['status' => 'error', 'message' => sprintf( __( 'HTTP error: %s', 'hfarazm-file-fetcher' ), $http )]);
    }

    $size = file_exists($full_path) ? filesize($full_path) : 0;

    // Check if user cancelled while download was running
    $progress_data = json_decode( file_get_contents($progress_file), true );
    if ( ! empty($progress_data['cancelled']) ) {
        wp_delete_file( $full_path );
        file_put_contents($progress_file, json_encode(['done' => true, 'cancelled' => true]), LOCK_EX);
        wp_send_json(['status' => 'cancelled']);
    }

    file_put_contents($progress_file, json_encode([
        'downloaded' => $size,
        'total'      => $size,
        'done'       => true,
    ]), LOCK_EX);

    $public_url = home_url( '/' . $filename );

    // Log to history
    $history   = get_option('srf_download_history', []);
    $history[] = [
        'url'        => $url,
        'filename'   => $filename,
        'path'       => $full_path,
        'public_url' => $public_url,
        'time'       => current_time('mysql'),
    ];
    update_option('srf_download_history', $history);

    wp_send_json([
        'status'   => 'success',
        'filename' => $filename,
        'path'     => $full_path,
        'size'     => $size,
    ]);
});

// ── AJAX: poll progress ──────────────────────────────────────────────────────
add_action('wp_ajax_srf_get_progress', function() {
    check_ajax_referer('srf_ajax_nonce', 'nonce');
    if ( ! current_user_can('manage_options') ) wp_die('Forbidden', 403);

    $token         = sanitize_key( wp_unslash( $_GET['token'] ?? '' ) );
    $progress_file = sys_get_temp_dir() . '/srf_progress_' . $token . '.json';

    if ( file_exists($progress_file) ) {
        $data = json_decode( file_get_contents($progress_file), true );
        if ( $data && ! empty($data['path']) && ! $data['done'] && file_exists($data['path']) ) {
            // Read actual bytes written so far for live progress
            $data['downloaded'] = filesize( $data['path'] );
        }
        unset( $data['path'] ); // do not expose server path to browser
        wp_send_json( $data ?: ['error' => 'invalid data'] );
    } else {
        wp_send_json(['error' => 'not found']);
    }
});

// ── AJAX: cancel download ────────────────────────────────────────────────────
add_action('wp_ajax_srf_cancel_download', function() {
    check_ajax_referer('srf_ajax_nonce', 'nonce');
    if ( ! current_user_can('manage_options') ) wp_die('Forbidden', 403);

    $token         = sanitize_key( wp_unslash( $_POST['token'] ?? '' ) );
    $progress_file = sys_get_temp_dir() . '/srf_progress_' . $token . '.json';

    if ( file_exists($progress_file) ) {
        $data              = json_decode( file_get_contents($progress_file), true ) ?: [];
        $data['cancelled'] = true;
        file_put_contents($progress_file, json_encode($data), LOCK_EX);
    }

    wp_send_json(['status' => 'ok']);
});

// ── Admin page ───────────────────────────────────────────────────────────────
function srf_fetcher_page() {
    $nonce = wp_create_nonce('srf_ajax_nonce');
    ?>
    <div class="wrap">
        <h2><?php esc_html_e( 'Remote File Fetcher', 'hfarazm-file-fetcher' ); ?></h2>

        <div style="display:flex;gap:28px;align-items:flex-start;">

            <!-- ── Main content ── -->
            <div style="flex:1;min-width:0;">

                <!-- URL input card -->
                <div style="background:#fff;border:1px solid #c3c4c7;border-radius:4px;box-shadow:0 1px 1px rgba(0,0,0,.04);padding:24px 28px 20px;margin-bottom:16px;">
                    <label for="srf_url" style="display:block;font-size:14px;font-weight:600;color:#1d2327;margin-bottom:10px;">
                        <?php esc_html_e( 'Remote File URL', 'hfarazm-file-fetcher' ); ?>
                    </label>
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <input
                            type="url"
                            id="srf_url"
                            style="flex:1;min-width:0;height:36px;font-size:14px;padding:0 10px;border:1px solid #8c8f94;border-radius:3px;box-shadow:inset 0 1px 2px rgba(0,0,0,.07);color:#2c3338;"
                            placeholder="<?php esc_attr_e( 'https://example.com/path/to/file.zip', 'hfarazm-file-fetcher' ); ?>"
                        >
                        <button id="srf_paste_btn" type="button" class="button" style="height:36px;white-space:nowrap;display:inline-flex;align-items:center;gap:5px;">
                            <span class="dashicons dashicons-clipboard" style="font-size:16px;width:16px;height:16px;margin-top:1px;"></span>
                            <?php esc_html_e( 'Paste', 'hfarazm-file-fetcher' ); ?>
                        </button>
                    </div>
                    <p style="margin:8px 0 0;font-size:12px;color:#646970;">
                        <?php esc_html_e( 'The file will be saved in the WordPress root directory using the filename from the URL.', 'hfarazm-file-fetcher' ); ?>
                    </p>
                    <div style="margin-top:16px;border-top:1px solid #f0f0f1;padding-top:16px;">
                        <button id="srf_fetch_btn" class="button button-primary button-large"><?php esc_html_e( 'Fetch File', 'hfarazm-file-fetcher' ); ?></button>
                    </div>
                </div>

                <!-- Status / conflict / progress area -->
                <div id="srf_status" style="display:none; margin:0 0 16px; padding:14px 18px; border:1px solid #c3c4c7; border-left:4px solid #72aee6; background:#f0f6fc; border-radius:3px; box-shadow:0 1px 1px rgba(0,0,0,.04);"></div>

                <?php srf_render_history(); ?>
            </div>

            <!-- ── Sidebar ── -->
            <div style="width:200px;flex-shrink:0;display:flex;flex-direction:column;gap:14px;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">

                <!-- How it works -->
                <div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:16px;">
                    <p style="margin:0 0 10px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#1d2327;"><?php esc_html_e( 'How It Works', 'hfarazm-file-fetcher' ); ?></p>
                    <ul style="margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:6px;">
                        <?php
                        $steps = [
                            __( 'Paste a file URL', 'hfarazm-file-fetcher' ),
                            __( 'Server fetches the file', 'hfarazm-file-fetcher' ),
                            __( 'Live progress shown', 'hfarazm-file-fetcher' ),
                            __( 'Saved to WP root', 'hfarazm-file-fetcher' ),
                            __( 'Download logged', 'hfarazm-file-fetcher' ),
                        ];
                        foreach ( $steps as $i => $step ) : ?>
                        <li style="display:flex;align-items:flex-start;gap:7px;font-size:12px;color:#3c434a;line-height:1.4;">
                            <span style="flex-shrink:0;width:16px;height:16px;border-radius:50%;background:#2271b1;color:#fff;font-size:9px;font-weight:700;display:flex;align-items:center;justify-content:center;margin-top:1px;"><?php echo absint( $i + 1 ); ?></span>
                            <?php echo esc_html($step); ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- Donate via PayPal -->
                <div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:16px;text-align:center;">
                    <p style="margin:0 0 10px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#1d2327;"><?php esc_html_e( 'Support This Plugin', 'hfarazm-file-fetcher' ); ?></p>
                    <p style="font-size:11px;color:#646970;margin:0 0 12px;line-height:1.5;"><?php esc_html_e( 'If this plugin saves you time, consider a small donation.', 'hfarazm-file-fetcher' ); ?></p>
                    <a href="https://www.paypal.com/donate/?hosted_button_id=U9SCFW8YL8M4J"
                       target="_blank" rel="noopener"
                       style="display:inline-flex;align-items:center;gap:7px;background:#003087;color:#fff;text-decoration:none;padding:8px 12px;border-radius:4px;font-size:12px;font-weight:600;width:100%;box-sizing:border-box;justify-content:center;">
                        <!-- PayPal logo mark -->
                        <svg width="16" height="18" viewBox="0 0 24 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19.5 3.5C18.5 1.5 16.3 1 13.8 1H6.3C5.6 1 5 1.5 4.9 2.2L2 20.2C1.9 20.7 2.3 21.2 2.8 21.2H7.3L8.4 14.2L8.3 14.6C8.4 13.9 9 13.4 9.7 13.4H12C16.4 13.4 19.8 11.6 20.8 6.4C20.8 6.3 20.9 6 20.9 6C21.2 4.8 20.9 4 19.5 3.5Z" fill="#009cde"/>
                            <path d="M20.8 6C20.8 6.3 20.8 6.3 20.8 6.4C19.8 11.6 16.4 13.4 12 13.4H9.7C9 13.4 8.4 13.9 8.3 14.6L6.8 23.8C6.7 24.2 7 24.6 7.5 24.6H11.4C12 24.6 12.5 24.2 12.6 23.6V23.3L13.4 18.3V18C13.5 17.4 14 17 14.6 17H15.2C18.9 17 21.8 15.5 22.6 11.1C23 9.3 22.8 7.7 21.8 6.7C21.5 6.4 21.2 6.2 20.8 6Z" fill="#012169"/>
                        </svg>
                        <?php esc_html_e( 'Donate via PayPal', 'hfarazm-file-fetcher' ); ?>
                    </a>
                </div>

                <!-- Hire on Fiverr -->
                <div style="background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:16px;text-align:center;">
                    <p style="margin:0 0 10px;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#1d2327;"><?php esc_html_e( 'Hire Me', 'hfarazm-file-fetcher' ); ?></p>
                    <p style="font-size:11px;color:#646970;margin:0 0 12px;line-height:1.5;"><?php esc_html_e( 'WordPress dev & SEO services available.', 'hfarazm-file-fetcher' ); ?></p>
                    <a href="https://www.fiverr.com/users/wordpressseodev"
                       target="_blank" rel="noopener"
                       style="display:inline-flex;align-items:center;gap:7px;background:#1dbf73;color:#fff;text-decoration:none;padding:8px 12px;border-radius:4px;font-size:12px;font-weight:600;width:100%;box-sizing:border-box;justify-content:center;margin-bottom:8px;">
                        <!-- Fiverr logo mark -->
                        <svg width="14" height="14" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="50" fill="#fff"/>
                            <text x="50" y="68" text-anchor="middle" font-size="52" font-family="Arial,sans-serif" font-weight="900" fill="#1dbf73">f</text>
                            <circle cx="73" cy="26" r="7" fill="#1dbf73"/>
                        </svg>
                        <?php esc_html_e( 'Fiverr Profile', 'hfarazm-file-fetcher' ); ?>
                    </a>
                    <a href="https://www.upwork.com/freelancers/hafizfaraz"
                       target="_blank" rel="noopener"
                       style="display:inline-flex;align-items:center;gap:7px;background:#14a800;color:#fff;text-decoration:none;padding:8px 12px;border-radius:4px;font-size:12px;font-weight:600;width:100%;box-sizing:border-box;justify-content:center;">
                        <!-- Upwork logo mark -->
                        <svg width="14" height="14" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="50" cy="50" r="50" fill="#fff"/>
                            <text x="50" y="68" text-anchor="middle" font-size="52" font-family="Arial,sans-serif" font-weight="900" fill="#14a800">U</text>
                        </svg>
                        <?php esc_html_e( 'Upwork Profile', 'hfarazm-file-fetcher' ); ?>
                    </a>
                </div>

            </div><!-- /sidebar -->
        </div><!-- /flex wrapper -->
    </div>

    <script>
    (function(){
        const ajaxUrl = <?php echo wp_json_encode( admin_url('admin-ajax.php') ); ?>;
        const nonce   = <?php echo wp_json_encode( $nonce ); ?>;

        const urlInput  = document.getElementById('srf_url');
        const fetchBtn  = document.getElementById('srf_fetch_btn');
        const statusBox = document.getElementById('srf_status');

        let pollTimer    = null;
        let pollSamples  = []; // [{time, bytes}] for speed calc
        let activeToken  = null;

        // ── Helpers ──────────────────────────────────────────────────────────

        function fmt_bytes(b) {
            if (b === 0 || b == null) return '0 B';
            const units = ['B','KB','MB','GB'];
            const i = Math.floor(Math.log(b) / Math.log(1024));
            return (b / Math.pow(1024, i)).toFixed(i > 0 ? 2 : 0) + ' ' + units[i];
        }

        function fmt_time(sec) {
            if (!isFinite(sec) || sec <= 0) return '—';
            if (sec < 60)  return Math.round(sec) + 's';
            if (sec < 3600) return Math.round(sec / 60) + 'm ' + Math.round(sec % 60) + 's';
            return Math.round(sec / 3600) + 'h ' + Math.round((sec % 3600) / 60) + 'm';
        }

        function show(html, borderColor) {
            statusBox.style.borderLeftColor = borderColor || '#72aee6';
            statusBox.innerHTML = html;
            statusBox.style.display = 'block';
        }

        function stopPolling() {
            if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
            pollSamples = [];
        }

        function setFetching(active) {
            fetchBtn.disabled = active;
            fetchBtn.textContent = active ? 'Fetching…' : 'Fetch File';
            // Warn user before leaving while a fetch is in progress
            if (active) {
                window.onbeforeunload = function() {
                    return 'File is still being fetched. If you leave, the download will be cancelled.';
                };
            } else {
                window.onbeforeunload = null;
            }
        }

        // ── Progress bar HTML ─────────────────────────────────────────────────

        function progressHTML(downloaded, total, speed, eta) {
            const pct      = total > 0 ? Math.min(100, Math.round(downloaded / total * 100)) : 0;
            const sizeText = total > 0
                ? fmt_bytes(downloaded) + ' / ' + fmt_bytes(total) + ' (' + pct + '%)'
                : fmt_bytes(downloaded) + ' downloaded (size unknown)';

            const barFill  = total > 0
                ? `<div style="height:100%;width:${pct}%;background:#2271b1;transition:width .4s ease;border-radius:3px;"></div>`
                : `<div style="height:100%;width:40%;background:#2271b1;animation:srf_indeterminate 1.2s infinite ease-in-out;border-radius:3px;"></div>`;

            return `
                <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:8px;">
                    <strong>Downloading&hellip;</strong>
                    <button id="srf_cancel_btn" class="button" style="color:#b32d2e;border-color:#b32d2e;">Cancel</button>
                </div>
                <div style="margin:0 0 4px;height:14px;background:#ddd;border-radius:3px;overflow:hidden;">${barFill}</div>
                <div style="display:flex;gap:24px;font-size:13px;color:#444;flex-wrap:wrap;margin-bottom:10px;">
                    <span>${sizeText}</span>
                    <span>Speed: <strong>${speed != null ? fmt_bytes(speed) + '/s' : '&mdash;'}</strong></span>
                    <span>ETA: <strong>${fmt_time(eta)}</strong></span>
                </div>
                <div style="font-size:12px;color:#b32d2e;background:#fef7f1;border:1px solid #f0b849;border-radius:3px;padding:7px 10px;">
                    <strong>Do not refresh this page or close this tab</strong> &mdash; doing so will cancel the download.
                </div>`;
        }

        // ── Polling ───────────────────────────────────────────────────────────

        function startPolling(token) {
            pollSamples = [];
            pollTimer = setInterval(function() {
                const params = new URLSearchParams({
                    action: 'srf_get_progress',
                    nonce:  nonce,
                    token:  token,
                });
                fetch(ajaxUrl + '?' + params)
                    .then(r => r.json())
                    .then(function(data) {
                        if (!data || data.error) return;

                        const now  = Date.now();
                        const dl   = data.downloaded || 0;
                        const tot  = data.total || 0;

                        // Rolling window speed (last 5s)
                        pollSamples.push({time: now, bytes: dl});
                        pollSamples = pollSamples.filter(s => now - s.time < 5000);

                        let speed = null, eta = Infinity;
                        if (pollSamples.length >= 2) {
                            const oldest = pollSamples[0];
                            const dt = (now - oldest.time) / 1000;
                            speed = dt > 0 ? (dl - oldest.bytes) / dt : 0;
                            if (speed > 0 && tot > 0) eta = (tot - dl) / speed;
                        }

                        if (!data.done) {
                            show(progressHTML(dl, tot, speed, eta), '#72aee6');
                            attachCancelBtn(token);
                        }
                        // When done, the fetch() promise resolves and handles the final state
                    });
            }, 600);
        }

        // ── Kick off download ─────────────────────────────────────────────────

        function attachCancelBtn(token) {
            const btn = document.getElementById('srf_cancel_btn');
            if (!btn) return;
            btn.onclick = function() {
                btn.disabled = true;
                btn.textContent = 'Cancelling…';
                const body = new FormData();
                body.append('action', 'srf_cancel_download');
                body.append('nonce',  nonce);
                body.append('token',  token);
                fetch(ajaxUrl, {method: 'POST', body: body});
                show('<strong>Cancelling&hellip;</strong><br><span style="font-size:13px;color:#646970;">Waiting for the current transfer to finish before removing the file.</span>', '#ffb900');
            };
        }

        function doFetch(url, conflictAction) {
            const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
            activeToken = token;

            setFetching(true);
            show(progressHTML(0, 0, null, null), '#72aee6');
            attachCancelBtn(token);
            startPolling(token);

            const body = new FormData();
            body.append('action',          'srf_start_download');
            body.append('nonce',           nonce);
            body.append('url',             url);
            body.append('conflict_action', conflictAction || 'none');
            body.append('token',           token);

            fetch(ajaxUrl, {method: 'POST', body: body})
                .then(r => r.json())
                .then(function(data) {
                    stopPolling();
                    setFetching(false);

                    if (data.status === 'conflict') {
                        show(`
                            <strong>&#9888; File already exists:</strong>
                            <code style="margin-left:6px;">${esc(data.filename)}</code><br>
                            <span style="font-size:13px;color:#555;">Choose how to proceed:</span>
                            <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:nowrap;align-items:center;">
                                <button class="button button-primary" id="srf_overwrite">Overwrite existing file</button>
                                <button class="button" id="srf_rename">Save as <strong>${esc(data.renamed)}</strong></button>
                            </div>
                        `, '#ffb900');

                        document.getElementById('srf_overwrite').onclick = function() {
                            doFetch(url, 'overwrite');
                        };
                        document.getElementById('srf_rename').onclick = function() {
                            doFetch(url, 'rename');
                        };

                    } else if (data.status === 'cancelled') {
                        show('&#10006; <strong>Download cancelled.</strong> The file was not saved.', '#d63638');

                    } else if (data.status === 'success') {
                        show(`
                            ✅ <strong>Done!</strong>
                            Saved <strong>${esc(data.filename)}</strong>
                            (${fmt_bytes(data.size)}) to:<br>
                            <code style="margin-top:4px;display:inline-block;">${esc(data.path)}</code>
                        `, '#00a32a');
                        // Refresh history table without full page reload
                        setTimeout(function() { location.reload(); }, 1800);

                    } else {
                        show('❌ <strong>Error:</strong> ' + esc(data.message || 'Unknown error.'), '#d63638');
                    }
                })
                .catch(function(err) {
                    stopPolling();
                    setFetching(false);
                    show('❌ <strong>Request failed:</strong> ' + esc(err.message), '#d63638');
                });
        }

        // ── Escape helper ─────────────────────────────────────────────────────

        function esc(str) {
            return String(str)
                .replace(/&/g,'&amp;').replace(/</g,'&lt;')
                .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
        }

        // ── Events ────────────────────────────────────────────────────────────

        fetchBtn.addEventListener('click', function() {
            const url = urlInput.value.trim();
            if (!url) { urlInput.focus(); return; }
            doFetch(url, 'none');
        });

        urlInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') fetchBtn.click();
        });

        // ── Paste from clipboard ──────────────────────────────────────────────
        const pasteBtn = document.getElementById('srf_paste_btn');
        if ( pasteBtn ) {
            pasteBtn.addEventListener('click', function() {
                if ( navigator.clipboard && navigator.clipboard.readText ) {
                    navigator.clipboard.readText().then(function(text) {
                        urlInput.value = text.trim();
                        urlInput.focus();
                        pasteBtn.textContent = ' Pasted!';
                        setTimeout(function() {
                            pasteBtn.innerHTML = '<span class="dashicons dashicons-clipboard" style="font-size:16px;width:16px;height:16px;margin-top:1px;vertical-align:middle;"></span> Paste';
                        }, 1500);
                    }).catch(function() {
                        urlInput.focus();
                        document.execCommand('paste');
                    });
                } else {
                    // Fallback for browsers without clipboard API
                    urlInput.focus();
                    document.execCommand('paste');
                }
            });
        }
    })();
    </script>

    <style>
    @keyframes srf_indeterminate {
        0%   { transform: translateX(-100%); width: 40%; }
        100% { transform: translateX(280%);  width: 40%; }
    }
    </style>
    <?php
}

// ── History table ────────────────────────────────────────────────────────────
function srf_render_history() {
    $history = get_option('srf_download_history', []);
    if ( empty($history) ) return;
    $history = array_reverse($history);
    ?>
    <h2 style="margin-top:28px;"><?php esc_html_e( 'Download History', 'hfarazm-file-fetcher' ); ?></h2>
    <table class="widefat striped" style="margin-top:10px;">
        <thead>
            <tr>
                <th style="width:36px;">#</th>
                <th><?php esc_html_e( 'Source URL', 'hfarazm-file-fetcher' ); ?></th>
                <th><?php esc_html_e( 'Saved To', 'hfarazm-file-fetcher' ); ?></th>
                <th style="width:140px;"><?php esc_html_e( 'Date &amp; Time', 'hfarazm-file-fetcher' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $history as $i => $entry ) :
                $public_url = ! empty($entry['public_url'])
                    ? $entry['public_url']
                    : home_url( '/' . basename($entry['path']) );
            ?>
            <tr>
                <td><?php echo absint( count($history) - $i ); ?></td>
                <td style="word-break:break-all;">
                    <a href="<?php echo esc_url($entry['url']); ?>" target="_blank" rel="noopener"><?php echo esc_html($entry['url']); ?></a>
                </td>
                <td>
                    <code style="font-size:11px;"><?php echo esc_html($entry['path']); ?></code>
                    <div style="margin-top:6px;display:flex;gap:8px;">
                        <a href="<?php echo esc_url($public_url); ?>"
                           target="_blank" rel="noopener"
                           style="font-size:11px;text-decoration:none;color:#2271b1;border:1px solid #2271b1;padding:2px 7px;border-radius:3px;white-space:nowrap;">
                            <?php esc_html_e( 'View file', 'hfarazm-file-fetcher' ); ?>
                        </a>
                        <button type="button"
                                class="srf-copy-link"
                                data-url="<?php echo esc_attr($public_url); ?>"
                                style="font-size:11px;cursor:pointer;background:none;border:1px solid #8c8f94;padding:2px 7px;border-radius:3px;color:#3c434a;white-space:nowrap;">
                            <?php esc_html_e( 'Copy link', 'hfarazm-file-fetcher' ); ?>
                        </button>
                    </div>
                </td>
                <td><?php echo esc_html($entry['time']); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <script>
    document.querySelectorAll('.srf-copy-link').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const url = this.getAttribute('data-url');
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(url).then(() => {
                    const orig = this.textContent;
                    this.textContent = 'Copied!';
                    setTimeout(() => { this.textContent = orig; }, 1500);
                });
            } else {
                const ta = document.createElement('textarea');
                ta.value = url;
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
                const orig = this.textContent;
                this.textContent = 'Copied!';
                setTimeout(() => { this.textContent = orig; }, 1500);
            }
        });
    });
    </script>
    <?php
}
?>
